

using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using master8GenNHibernate.EN.Petstore3;
using master8GenNHibernate.CAD.Petstore3;

namespace master8GenNHibernate.CEN.Petstore3
{
        public partial class PedidoCEN
        {
        private IPedidoCAD _IPedidoCAD;

        public PedidoCEN(IPedidoCAD _IPedidoCAD)
        {
                this._IPedidoCAD = _IPedidoCAD;
        }

        public int CrearPedido (String p_descripcion, Nullable<DateTime> p_fechaRealizacion, System.Collections.Generic.IList<master8GenNHibernate.EN.Petstore3.LineaPedidoEN> p_lineaPedido, String p_cliente, Nullable<DateTime> p_fechaEnvio, String p_estado)
        {
                PedidoEN pedidoEN = null;
                int oid;

                //Initialized PedidoEN
                pedidoEN = new PedidoEN ();
                pedidoEN.Descripcion = p_descripcion;
                pedidoEN.FechaRealizacion = p_fechaRealizacion;
                pedidoEN.LineaPedido = p_lineaPedido;
                if (p_cliente != null) {
                        pedidoEN.Cliente = new master8GenNHibernate.EN.Petstore3.ClienteEN ();
                        pedidoEN.Cliente.NIF = p_cliente;
                }
                pedidoEN.FechaEnvio = p_fechaEnvio;
                pedidoEN.Estado = p_estado;
                //Call to PedidoCAD

                oid = _IPedidoCAD.CrearPedido (pedidoEN);
                return oid;
        }

        public void ModificarPedido (int p_Pedido_OID, String p_descripcion, Nullable<DateTime> p_fechaRealizacion, Nullable<DateTime> p_fechaEnvio, String p_estado)
        {
                PedidoEN pedidoEN = null;

                //Initialized PedidoEN
                pedidoEN = new PedidoEN ();
                pedidoEN.Id = p_Pedido_OID;
                pedidoEN.Descripcion = p_descripcion;
                pedidoEN.FechaRealizacion = p_fechaRealizacion;
                pedidoEN.FechaEnvio = p_fechaEnvio;
                pedidoEN.Estado = p_estado;
                //Call to PedidoCAD

                _IPedidoCAD.ModificarPedido (pedidoEN);
        }

        public void BorrarPedido (int id)
        {
                _IPedidoCAD.BorrarPedido (
                        id

                        );
        }

        public PedidoEN ReadOID (int id)
        {
                PedidoEN pedidoEN = null;

                pedidoEN = _IPedidoCAD.ReadOID (
                        id

                        );
                return pedidoEN;
        }
        }
}
