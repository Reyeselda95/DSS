

using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using master8GenNHibernate.EN.Petstore3;
using master8GenNHibernate.CAD.Petstore3;

namespace master8GenNHibernate.CEN.Petstore3
{
        public partial class CategoriaCEN
        {
        private ICategoriaCAD _ICategoriaCAD;

        public CategoriaCEN(ICategoriaCAD _ICategoriaCAD)
        {
                this._ICategoriaCAD = _ICategoriaCAD;
        }

        public int Nueva (String p_nombre, String p_descripcion, String p_foto)
        {
                CategoriaEN categoriaEN = null;
                int oid;

                //Initialized CategoriaEN
                categoriaEN = new CategoriaEN ();
                categoriaEN.Nombre = p_nombre;
                categoriaEN.Descripcion = p_descripcion;
                categoriaEN.Foto = p_foto;
                //Call to CategoriaCAD

                oid = _ICategoriaCAD.Nueva (categoriaEN);
                return oid;
        }

        public void Borrar (int id)
        {
                _ICategoriaCAD.Borrar (
                        id

                        );
        }

        public CategoriaEN DamePorOID (int id)
        {
                CategoriaEN categoriaEN = null;

                categoriaEN = _ICategoriaCAD.DamePorOID (
                        id

                        );
                return categoriaEN;
        }

        public System.Collections.Generic.IList<CategoriaEN> DameTodos (int first, int size)
        {
                System.Collections.Generic.IList<CategoriaEN> list = null;

                list = _ICategoriaCAD.DameTodos (first, size);
                return list;
        }
        public void NuevaSubCategoria (int p_Categoria_OID, System.Collections.Generic.IList<int> p_subCategoria_OIDs)
        {
                //Call to CategoriaCAD

                _ICategoriaCAD.NuevaSubCategoria (p_Categoria_OID, p_subCategoria_OIDs);
        }
        }
}
