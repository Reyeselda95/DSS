
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using master8GenNHibernate.EN.Petstore3;
using master8GenNHibernate.CAD.Petstore3;

namespace master8GenNHibernate.CEN.Petstore3
{
        public partial class ClienteCEN
        {
        public String Deslogarse (String nIF)
        {
                /*PROTECTED REGION ID(Petstore3.ClienteCEN_deslogarse_precondition) START*/

                // Preconditions
                // if( !() )
                //              throw new ModelException("Method Deslogarse() preconditions are violated.");

                /*PROTECTED REGION END*/

                /*PROTECTED REGION ID(Petstore3.ClienteCEN_deslogarse_body) ENABLED START*/

                // Body
                throw new NotImplementedException ("Method Deslogarse() not yet implemented.");

                /*PROTECTED REGION END*/

                /*PROTECTED REGION ID(Petstore3.ClienteCEN_deslogarse_postcondition) START*/

                // Postconditions
                // if( !() )
                //              throw new ModelException("Method Deslogarse() postconditions are violated.");

                /*PROTECTED REGION END*/
        }
        }
}
