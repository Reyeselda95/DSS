

using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using master8GenNHibernate.EN.Petstore3;
using master8GenNHibernate.CAD.Petstore3;

namespace master8GenNHibernate.CEN.Petstore3
{
        public partial class ClienteCEN
        {
        private IClienteCAD _IClienteCAD;

        public ClienteCEN(IClienteCAD _IClienteCAD)
        {
                this._IClienteCAD = _IClienteCAD;
        }

        public String CrearCliente (String p_NIF, String p_nombre, String p_apellidos, String p_direccion, String p_telefono, String p_cp, String p_password)
        {
                ClienteEN clienteEN = null;
                String oid;

                //Initialized ClienteEN
                clienteEN = new ClienteEN ();
                clienteEN.NIF = p_NIF;
                clienteEN.Nombre = p_nombre;
                clienteEN.Apellidos = p_apellidos;
                clienteEN.Direccion = p_direccion;
                clienteEN.Telefono = p_telefono;
                clienteEN.Cp = p_cp;
                clienteEN.Password = p_password;
                //Call to ClienteCAD

                oid = _IClienteCAD.CrearCliente (clienteEN);
                return oid;
        }

        public void ModificarCliente (String p_Cliente_OID, String p_nombre, String p_apellidos, String p_direccion, String p_telefono, String p_cp, String p_password)
        {
                ClienteEN clienteEN = null;

                //Initialized ClienteEN
                clienteEN = new ClienteEN ();
                clienteEN.NIF = p_Cliente_OID;
                clienteEN.Nombre = p_nombre;
                clienteEN.Apellidos = p_apellidos;
                clienteEN.Direccion = p_direccion;
                clienteEN.Telefono = p_telefono;
                clienteEN.Cp = p_cp;
                clienteEN.Password = p_password;
                //Call to ClienteCAD

                _IClienteCAD.ModificarCliente (clienteEN);
        }

        public void BorrarCliente (String NIF)
        {
                _IClienteCAD.BorrarCliente (
                        NIF

                        );
        }

        public System.Collections.Generic.IList<ClienteEN> DameTodos (int first, int size)
        {
                System.Collections.Generic.IList<ClienteEN> list = null;

                list = _IClienteCAD.DameTodos (first, size);
                return list;
        }
        }
}
