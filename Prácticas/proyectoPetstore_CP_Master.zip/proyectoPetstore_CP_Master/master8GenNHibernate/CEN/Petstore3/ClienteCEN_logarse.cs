
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using master8GenNHibernate.EN.Petstore3;
using master8GenNHibernate.CAD.Petstore3;

namespace master8GenNHibernate.CEN.Petstore3
{
    public partial class ClienteCEN
    {
        public bool Logarse(String nIF, String password)
        {
            /*PROTECTED REGION ID(CEN_Petstore3_logarse_precondition) ENABLED START*/

            // Preconditions
            ClienteEN clienteEN = null;
            bool login=false;
            if (nIF != null && password != null)
            /*PROTECTED REGION END*/
            /*PROTECTED REGION ID(CEN_Petstore3_logarse_body) ENABLED START*/
            {
                clienteEN = _IClienteCAD.ReadOIDDefault(nIF);

                /*PROTECTED REGION END*/
                /*PROTECTED REGION ID(CEN_Petstore3_logarse_postcondition) START*/
                if (clienteEN.Password == password)
                    login = true;
            }
            return login;
            /*PROTECTED REGION END*/
        }
    }
}
