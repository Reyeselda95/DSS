

using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using master8GenNHibernate.EN.Petstore3;
using master8GenNHibernate.CAD.Petstore3;

namespace master8GenNHibernate.CEN.Petstore3
{
        public partial class ArticuloCEN
        {
        private IArticuloCAD _IArticuloCAD;

        public ArticuloCEN(IArticuloCAD _IArticuloCAD)
        {
                this._IArticuloCAD = _IArticuloCAD;
        }

        public int NuevoArticulo (int p_numero, String p_nombre, String p_foto, double p_precio, int p_cantidad, int p_categoria, String p_fotoGrande)
        {
                ArticuloEN articuloEN = null;
                int oid;

                //Initialized ArticuloEN
                articuloEN = new ArticuloEN ();
                articuloEN.Numero = p_numero;
                articuloEN.Nombre = p_nombre;
                articuloEN.Foto = p_foto;
                articuloEN.Precio = p_precio;
                articuloEN.Cantidad = p_cantidad;
                if (p_categoria != -1) {
                        articuloEN.Categoria = new master8GenNHibernate.EN.Petstore3.CategoriaEN ();
                        articuloEN.Categoria.Id = p_categoria;
                }
                articuloEN.FotoGrande = p_fotoGrande;
                //Call to ArticuloCAD

                oid = _IArticuloCAD.NuevoArticulo (articuloEN);
                return oid;
        }

        public void BorrarArticulo (int numero)
        {
                _IArticuloCAD.BorrarArticulo (
                        numero

                        );
        }

        public void Modificar (int p_Articulo_OID, String p_nombre, String p_foto, double p_precio, int p_cantidad, String p_fotoGrande)
        {
                ArticuloEN articuloEN = null;

                //Initialized ArticuloEN
                articuloEN = new ArticuloEN ();
                articuloEN.Numero = p_Articulo_OID;
                articuloEN.Nombre = p_nombre;
                articuloEN.Foto = p_foto;
                articuloEN.Precio = p_precio;
                articuloEN.Cantidad = p_cantidad;
                articuloEN.FotoGrande = p_fotoGrande;
                //Call to ArticuloCAD

                _IArticuloCAD.Modificar (articuloEN);
        }

        public void AnyadirAPedido (int p_Articulo_OID, System.Collections.Generic.IList<int> p_lineaPedido_OIDs)
        {
                //Call to ArticuloCAD

                _IArticuloCAD.AnyadirAPedido (p_Articulo_OID, p_lineaPedido_OIDs);
        }
        public void QuitarDePedido (int p_Articulo_OID, System.Collections.Generic.IList<int> p_lineaPedido_OIDs)
        {
                //Call to ArticuloCAD

                _IArticuloCAD.QuitarDePedido (p_Articulo_OID, p_lineaPedido_OIDs);
        }
        public ArticuloEN DamePorOID (int numero)
        {
                ArticuloEN articuloEN = null;

                articuloEN = _IArticuloCAD.DamePorOID (
                        numero

                        );
                return articuloEN;
        }

        public System.Collections.Generic.IList<ArticuloEN> DameTodos (int first, int size)
        {
                System.Collections.Generic.IList<ArticuloEN> list = null;

                list = _IArticuloCAD.DameTodos (first, size);
                return list;
        }
        }
}
