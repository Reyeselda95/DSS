
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using master8GenNHibernate.EN.Petstore3;
using master8GenNHibernate.CAD.Petstore3;

namespace master8GenNHibernate.CEN.Petstore3
{
        public partial class ArticuloCEN
        {
        public String BuscarPorFiltro (String filtro)
        {
                /*PROTECTED REGION ID(Petstore3.ArticuloCEN_buscarPorFiltro_precondition) START*/

                // Preconditions
                // if( !() )
                //              throw new ModelException("Method BuscarPorFiltro() preconditions are violated.");

                /*PROTECTED REGION END*/

                /*PROTECTED REGION ID(Petstore3.ArticuloCEN_buscarPorFiltro_body) ENABLED START*/

                // Body
                throw new NotImplementedException ("Method BuscarPorFiltro() not yet implemented.");

                /*PROTECTED REGION END*/

                /*PROTECTED REGION ID(Petstore3.ArticuloCEN_buscarPorFiltro_postcondition) START*/

                // Postconditions
                // if( !() )
                //              throw new ModelException("Method BuscarPorFiltro() postconditions are violated.");

                /*PROTECTED REGION END*/
        }
        }
}
