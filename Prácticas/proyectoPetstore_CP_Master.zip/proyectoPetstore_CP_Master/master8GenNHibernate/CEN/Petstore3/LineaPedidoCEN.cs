

using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using master8GenNHibernate.EN.Petstore3;
using master8GenNHibernate.CAD.Petstore3;

namespace master8GenNHibernate.CEN.Petstore3
{
        public partial class LineaPedidoCEN
        {
        private ILineaPedidoCAD _ILineaPedidoCAD;

        public LineaPedidoCEN(ILineaPedidoCAD _ILineaPedidoCAD)
        {
                this._ILineaPedidoCAD = _ILineaPedidoCAD;
        }

        public int New_ (int p_numLinea, int p_articulo, int p_cantidad, double p_subtotal, String p_observacion)
        {
                LineaPedidoEN lineaPedidoEN = null;
                int oid;

                //Initialized LineaPedidoEN
                lineaPedidoEN = new LineaPedidoEN ();
                lineaPedidoEN.NumLinea = p_numLinea;
                if (p_articulo != -1) {
                        lineaPedidoEN.Articulo = new master8GenNHibernate.EN.Petstore3.ArticuloEN ();
                        lineaPedidoEN.Articulo.Numero = p_articulo;
                }
                lineaPedidoEN.Cantidad = p_cantidad;
                lineaPedidoEN.Subtotal = p_subtotal;
                lineaPedidoEN.Observacion = p_observacion;
                //Call to LineaPedidoCAD

                oid = _ILineaPedidoCAD.New_ (lineaPedidoEN);
                return oid;
        }

        public void Destroy (int numLinea)
        {
                _ILineaPedidoCAD.Destroy (
                        numLinea

                        );
        }

        public void RelationerLinea (int p_LineaPedido_OID, int p_pedido_OID)
        {
                //Call to LineaPedidoCAD

                _ILineaPedidoCAD.RelationerLinea (p_LineaPedido_OID, p_pedido_OID);
        }
        }
}
