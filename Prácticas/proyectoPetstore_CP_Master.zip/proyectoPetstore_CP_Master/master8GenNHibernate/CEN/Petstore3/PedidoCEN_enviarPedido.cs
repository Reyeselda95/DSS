
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using master8GenNHibernate.EN.Petstore3;
using master8GenNHibernate.CAD.Petstore3;

namespace master8GenNHibernate.CEN.Petstore3
{
        public partial class PedidoCEN
        {
        public String EnviarPedido (Nullable<DateTime> fecha, int idPedido)
        {
                /*PROTECTED REGION ID(Petstore3.PedidoCEN_enviarPedido_precondition) START*/

                // Preconditions
                // if( !(true) )
                //              throw new ModelException("Method EnviarPedido() preconditions are violated.");

                /*PROTECTED REGION END*/

                /*PROTECTED REGION ID(Petstore3.PedidoCEN_enviarPedido_body) ENABLED START*/

                // Body
                throw new NotImplementedException ("Method EnviarPedido() not yet implemented.");

                /*PROTECTED REGION END*/

                /*PROTECTED REGION ID(Petstore3.PedidoCEN_enviarPedido_postcondition) START*/

                // Postconditions
                // if( !(false) )
                //              throw new ModelException("Method EnviarPedido() postconditions are violated.");

                /*PROTECTED REGION END*/
        }
        }
}
