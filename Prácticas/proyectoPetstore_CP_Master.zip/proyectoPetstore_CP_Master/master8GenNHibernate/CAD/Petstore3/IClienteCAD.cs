
using System;
using master8GenNHibernate.EN.Petstore3;

namespace master8GenNHibernate.CAD.Petstore3
{
        public interface IClienteCAD
        {
        ClienteEN ReadOIDDefault (String NIF);

        String CrearCliente (ClienteEN cliente);

        void ModificarCliente (ClienteEN cliente);


        void BorrarCliente (String NIF);


        System.Collections.Generic.IList<ClienteEN> DameTodos (int first, int size);




        System.Collections.Generic.IList<EN.Petstore3.PedidoEN>         DamePedidosAnteriores (String NIF);

        System.Collections.Generic.IList<EN.Petstore3.PedidoEN>         DameCarrito (String NIF);
        }
}
