
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using master8GenNHibernate.EN.Petstore3;

namespace master8GenNHibernate.CAD.Petstore3
{
        public class LineaPedidoCAD : BasicCAD, ILineaPedidoCAD
        {
        public LineaPedidoCAD() : base ()
        {
        }

        public LineaPedidoCAD(ISession sessionAux) : base (sessionAux)
        {
        }



        public LineaPedidoEN ReadOIDDefault (int numLinea)
        {
                LineaPedidoEN lineaPedidoEN = null;

                try
                {
                        SesssionInitializeTransaction ();
                        lineaPedidoEN = (LineaPedidoEN)session.Load (typeof(LineaPedidoEN),
                                numLinea

                                );
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in LineaPedidoCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }

                return lineaPedidoEN;
        }


        public int New_ (LineaPedidoEN lineaPedido)
        {
                try
                {
                        SesssionInitializeTransaction ();
                        if (lineaPedido.Articulo != null) {
                                lineaPedido.Articulo = (master8GenNHibernate.EN.Petstore3.ArticuloEN)session.Load (typeof(master8GenNHibernate.EN.Petstore3.ArticuloEN), lineaPedido.Articulo.Numero);
                        }

                        session.Save (lineaPedido);
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in LineaPedidoCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }

                return lineaPedido.NumLinea;
        }

        public void Destroy (int numLinea)
        {
                try
                {
                        SesssionInitializeTransaction ();
                        LineaPedidoEN lineaPedidoEN = (LineaPedidoEN)session.Load (typeof(LineaPedidoEN),
                                numLinea

                                );
                        session.Delete (lineaPedidoEN);
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in LineaPedidoCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }
        }

        public void RelationerLinea (int p_LineaPedido_OID, int p_pedido_OID)
        {
                master8GenNHibernate.EN.Petstore3.LineaPedidoEN lineaPedidoEN = null;
                try
                {
                        SesssionInitializeTransaction ();
                        lineaPedidoEN = (LineaPedidoEN)session.Load (typeof(LineaPedidoEN), p_LineaPedido_OID);
                        lineaPedidoEN.Pedido = (EN.Petstore3.PedidoEN)session.Load (typeof(EN.Petstore3.PedidoEN), p_pedido_OID);

                        session.Update (lineaPedidoEN);
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in LineaPedidoCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }
        }





        public EN.Petstore3.ArticuloEN         GetArticulo (int numLinea)
        {
                EN.Petstore3.ArticuloEN result = null;
                try
                {
                        using (ISession session = NHibernateHelper.OpenSession ())
                                using (ITransaction tx = session.BeginTransaction ())
                                {
                                        String sql = @"select self FROM ArticuloEN self inner join self.LineaPedido as target with target.NumLinea=:p_NumLinea";
                                        IQuery query = session.CreateQuery (sql).SetParameter ("p_NumLinea", numLinea);



                                        result = query.UniqueResult<EN.Petstore3.ArticuloEN>();
                                }
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in LineaPedidoCAD.", ex);
                }

                return result;
        }
        }
}
