
using System;
using master8GenNHibernate.EN.Petstore3;

namespace master8GenNHibernate.CAD.Petstore3
{
        public interface IArticuloCAD
        {
        ArticuloEN ReadOIDDefault (int numero);

        int NuevoArticulo (ArticuloEN articulo);

        void BorrarArticulo (int numero);


        void Modificar (ArticuloEN articulo);


        void AnyadirAPedido (int p_Articulo_OID, System.Collections.Generic.IList<int> p_lineaPedido_OIDs);

        void QuitarDePedido (int p_Articulo_OID, System.Collections.Generic.IList<int> p_lineaPedido_OIDs);


        ArticuloEN DamePorOID (int numero);


        System.Collections.Generic.IList<ArticuloEN> DameTodos (int first, int size);
        }
}
