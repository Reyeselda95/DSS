
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using master8GenNHibernate.EN.Petstore3;

namespace master8GenNHibernate.CAD.Petstore3
{
        public class CategoriaCAD : BasicCAD, ICategoriaCAD
        {
        public CategoriaCAD() : base ()
        {
        }

        public CategoriaCAD(ISession sessionAux) : base (sessionAux)
        {
        }



        public CategoriaEN ReadOIDDefault (int id)
        {
                CategoriaEN categoriaEN = null;

                try
                {
                        SesssionInitializeTransaction ();
                        categoriaEN = (CategoriaEN)session.Load (typeof(CategoriaEN),
                                id

                                );
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in CategoriaCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }

                return categoriaEN;
        }


        public int Nueva (CategoriaEN categoria)
        {
                try
                {
                        SesssionInitializeTransaction ();

                        session.Save (categoria);
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in CategoriaCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }

                return categoria.Id;
        }

        public void Borrar (int id)
        {
                try
                {
                        SesssionInitializeTransaction ();
                        CategoriaEN categoriaEN = (CategoriaEN)session.Load (typeof(CategoriaEN),
                                id

                                );
                        session.Delete (categoriaEN);
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in CategoriaCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }
        }

        public CategoriaEN DamePorOID (int id)
        {
                CategoriaEN categoriaEN = null;

                try
                {
                        SesssionInitializeTransaction ();
                        categoriaEN = (CategoriaEN)session.Load (typeof(CategoriaEN),
                                id

                                );
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in CategoriaCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }

                return categoriaEN;
        }

        public System.Collections.Generic.IList<CategoriaEN> DameTodos (int first, int size)
        {
                System.Collections.Generic.IList<CategoriaEN> result = null;
                try
                {
                        SesssionInitializeTransaction ();
                        if (size > 0)
                                result = session.CreateCriteria (typeof(CategoriaEN)).
                                         SetFirstResult (first).SetMaxResults (size).List<CategoriaEN>();
                        else
                                result = session.CreateCriteria (typeof(CategoriaEN)).List<CategoriaEN>();
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in CategoriaCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }

                return result;
        }

        public void NuevaSubCategoria (int p_Categoria_OID, System.Collections.Generic.IList<int> p_subCategoria_OIDs)
        {
                master8GenNHibernate.EN.Petstore3.CategoriaEN categoriaEN = null;
                try
                {
                        SesssionInitializeTransaction ();
                        categoriaEN = (CategoriaEN)session.Load (typeof(CategoriaEN), p_Categoria_OID);
                        EN.Petstore3.CategoriaEN subCategoriaEN = null;
                        if (categoriaEN.SubCategoria == null) {
                                categoriaEN.SubCategoria = new System.Collections.Generic.List<EN.Petstore3.CategoriaEN>();
                        }

                        foreach (int item in p_subCategoria_OIDs) {
                                subCategoriaEN = new EN.Petstore3.CategoriaEN ();
                                subCategoriaEN = (EN.Petstore3.CategoriaEN)session.Load (typeof(EN.Petstore3.CategoriaEN), item);
                                categoriaEN.SubCategoria.Add (subCategoriaEN);
                        }


                        session.Update (categoriaEN);
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in CategoriaCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }
        }





        public System.Collections.Generic.IList<EN.Petstore3.CategoriaEN>      DameSubCategorias (int id)
        {
                System.Collections.Generic.IList<EN.Petstore3.CategoriaEN> result = null;
                try
                {
                        using (ISession session = NHibernateHelper.OpenSession ())
                                using (ITransaction tx = session.BeginTransaction ())
                                {
                                        String sql = @"select self FROM CategoriaEN self inner join self.Categoria as target with target.Id=:p_Id";
                                        IQuery query = session.CreateQuery (sql).SetParameter ("p_Id", id);



                                        result = query.List<EN.Petstore3.CategoriaEN>();
                                }
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in CategoriaCAD.", ex);
                }

                return result;
        }

        public System.Collections.Generic.IList<EN.Petstore3.ArticuloEN>       DameArticulosDeCategorias (int id)
        {
                System.Collections.Generic.IList<EN.Petstore3.ArticuloEN> result = null;
                try
                {
                        using (ISession session = NHibernateHelper.OpenSession ())
                                using (ITransaction tx = session.BeginTransaction ())
                                {
                                        String sql = @"select self FROM ArticuloEN self inner join self.Categoria as target with target.Id=:p_Id";
                                        IQuery query = session.CreateQuery (sql).SetParameter ("p_Id", id);



                                        result = query.List<EN.Petstore3.ArticuloEN>();
                                }
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in CategoriaCAD.", ex);
                }

                return result;
        }




        public System.Collections.Generic.IList<master8GenNHibernate.EN.Petstore3.CategoriaEN> DameTodasLasFamilias ()
        {
                System.Collections.Generic.IList<master8GenNHibernate.EN.Petstore3.CategoriaEN> result = null;
                try
                {
                        using (ISession session = NHibernateHelper.OpenSession ())
                                using (ITransaction tx = session.BeginTransaction ())
                                {
                                        String sql = "from CategoriaEN self";
                                        IQuery query = session.CreateQuery (sql);

                                        result = query.List<CategoriaEN>();
                                }
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in CategoriaCAD.", ex);
                }

                return result;
        }
        }
}
