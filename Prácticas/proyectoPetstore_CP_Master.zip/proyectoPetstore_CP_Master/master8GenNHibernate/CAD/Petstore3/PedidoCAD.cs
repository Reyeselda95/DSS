
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using master8GenNHibernate.EN.Petstore3;

namespace master8GenNHibernate.CAD.Petstore3
{
        public class PedidoCAD : BasicCAD, IPedidoCAD
        {
        public PedidoCAD() : base ()
        {
        }

        public PedidoCAD(ISession sessionAux) : base (sessionAux)
        {
        }



        public PedidoEN ReadOIDDefault (int id)
        {
                PedidoEN pedidoEN = null;

                try
                {
                        SesssionInitializeTransaction ();
                        pedidoEN = (PedidoEN)session.Load (typeof(PedidoEN),
                                id

                                );
                        //SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in PedidoCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }

                return pedidoEN;
        }


        public int CrearPedido (PedidoEN pedido)
        {
                try
                {
                        SesssionInitializeTransaction ();
                        if (pedido.LineaPedido != null) {
                                foreach (master8GenNHibernate.EN.Petstore3.LineaPedidoEN item in pedido.LineaPedido)
                                        session.Save (item);
                        }
                        if (pedido.Cliente != null) {
                                pedido.Cliente = (master8GenNHibernate.EN.Petstore3.ClienteEN)session.Load (typeof(master8GenNHibernate.EN.Petstore3.ClienteEN), pedido.Cliente.NIF);
                        }

                        session.Save (pedido);
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in PedidoCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }

                return pedido.Id;
        }

        public void ModificarPedido (PedidoEN pedido)
        {
                try
                {
                        SesssionInitializeTransaction ();
                        PedidoEN pedidoEN = (PedidoEN)session.Load (typeof(PedidoEN), pedido.Id);

                        pedidoEN.Descripcion = pedido.Descripcion;


                        pedidoEN.FechaRealizacion = pedido.FechaRealizacion;


                        pedidoEN.FechaEnvio = pedido.FechaEnvio;


                        pedidoEN.Estado = pedido.Estado;

                        session.Update (pedidoEN);
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in PedidoCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }
        }
        public void BorrarPedido (int id)
        {
                try
                {
                        SesssionInitializeTransaction ();
                        PedidoEN pedidoEN = (PedidoEN)session.Load (typeof(PedidoEN),
                                id

                                );
                        session.Delete (pedidoEN);
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in PedidoCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }
        }

        public PedidoEN ReadOID (int id)
        {
                PedidoEN pedidoEN = null;

                try
                {
                        SesssionInitializeTransaction ();
                        pedidoEN = (PedidoEN)session.Load (typeof(PedidoEN),
                                id

                                );
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in PedidoCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }

                return pedidoEN;
        }





        public System.Collections.Generic.IList<EN.Petstore3.LineaPedidoEN>    GetAllLineaPedidos (int id)
        {
                System.Collections.Generic.IList<EN.Petstore3.LineaPedidoEN> result = null;
                try
                {
                        using (ISession session = NHibernateHelper.OpenSession ())
                                using (ITransaction tx = session.BeginTransaction ())
                                {
                                        String sql = @"select self FROM LineaPedidoEN self inner join self.Pedido as target with target.Id=:p_Id";
                                        IQuery query = session.CreateQuery (sql).SetParameter ("p_Id", id);



                                        result = query.List<EN.Petstore3.LineaPedidoEN>();
                                }
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in PedidoCAD.", ex);
                }

                return result;
        }

        public System.Collections.Generic.IList<EN.Petstore3.LineaPedidoEN>    DameLineas (int id)
        {
                System.Collections.Generic.IList<EN.Petstore3.LineaPedidoEN> result = null;
                try
                {
                        using (ISession session = NHibernateHelper.OpenSession ())
                                using (ITransaction tx = session.BeginTransaction ())
                                {
                                        String sql = @"select self FROM LineaPedidoEN self inner join self.Pedido as target with target.Id=:p_Id";
                                        IQuery query = session.CreateQuery (sql).SetParameter ("p_Id", id);



                                        result = query.List<EN.Petstore3.LineaPedidoEN>();
                                }
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in PedidoCAD.", ex);
                }

                return result;
        }
        }
}
