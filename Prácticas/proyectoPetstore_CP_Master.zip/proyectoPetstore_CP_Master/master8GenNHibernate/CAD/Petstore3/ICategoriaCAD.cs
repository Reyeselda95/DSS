
using System;
using master8GenNHibernate.EN.Petstore3;

namespace master8GenNHibernate.CAD.Petstore3
{
        public interface ICategoriaCAD
        {
        CategoriaEN ReadOIDDefault (int id);

        int Nueva (CategoriaEN categoria);

        void Borrar (int id);


        CategoriaEN DamePorOID (int id);


        System.Collections.Generic.IList<CategoriaEN> DameTodos (int first, int size);


        void NuevaSubCategoria (int p_Categoria_OID, System.Collections.Generic.IList<int> p_subCategoria_OIDs);

        System.Collections.Generic.IList<EN.Petstore3.CategoriaEN>      DameSubCategorias (int id);

        System.Collections.Generic.IList<EN.Petstore3.ArticuloEN>       DameArticulosDeCategorias (int id);


        System.Collections.Generic.IList<master8GenNHibernate.EN.Petstore3.CategoriaEN> DameTodasLasFamilias ();
        }
}
