
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using master8GenNHibernate.EN.Petstore3;

namespace master8GenNHibernate.CAD.Petstore3
{
        public class ClienteCAD : BasicCAD, IClienteCAD
        {
        public ClienteCAD() : base ()
        {
        }

        public ClienteCAD(ISession sessionAux) : base (sessionAux)
        {
        }



        public ClienteEN ReadOIDDefault (String NIF)
        {
                ClienteEN clienteEN = null;

                try
                {
                        SesssionInitializeTransaction ();
                        clienteEN = (ClienteEN)session.Load (typeof(ClienteEN),
                                NIF

                                );
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in ClienteCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }

                return clienteEN;
        }


        public String CrearCliente (ClienteEN cliente)
        {
                try
                {
                        SesssionInitializeTransaction ();

                        session.Save (cliente);
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in ClienteCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }

                return cliente.NIF;
        }

        public void ModificarCliente (ClienteEN cliente)
        {
                try
                {
                        SesssionInitializeTransaction ();
                        ClienteEN clienteEN = (ClienteEN)session.Load (typeof(ClienteEN), cliente.NIF);

                        clienteEN.Nombre = cliente.Nombre;


                        clienteEN.Apellidos = cliente.Apellidos;


                        clienteEN.Direccion = cliente.Direccion;


                        clienteEN.Telefono = cliente.Telefono;


                        clienteEN.Cp = cliente.Cp;


                        clienteEN.Password = cliente.Password;

                        session.Update (clienteEN);
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in ClienteCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }
        }
        public void BorrarCliente (String NIF)
        {
                try
                {
                        SesssionInitializeTransaction ();
                        ClienteEN clienteEN = (ClienteEN)session.Load (typeof(ClienteEN),
                                NIF

                                );
                        session.Delete (clienteEN);
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in ClienteCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }
        }

        public System.Collections.Generic.IList<ClienteEN> DameTodos (int first, int size)
        {
                System.Collections.Generic.IList<ClienteEN> result = null;
                try
                {
                        SesssionInitializeTransaction ();
                        if (size > 0)
                                result = session.CreateCriteria (typeof(ClienteEN)).
                                         SetFirstResult (first).SetMaxResults (size).List<ClienteEN>();
                        else
                                result = session.CreateCriteria (typeof(ClienteEN)).List<ClienteEN>();
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in ClienteCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }

                return result;
        }





        public System.Collections.Generic.IList<EN.Petstore3.PedidoEN>         DamePedidosAnteriores (String NIF)
        {
                System.Collections.Generic.IList<EN.Petstore3.PedidoEN> result = null;
                try
                {
                        using (ISession session = NHibernateHelper.OpenSession ())
                                using (ITransaction tx = session.BeginTransaction ())
                                {
                                        String sql = @"select self FROM PedidoEN self inner join self.Cliente as target with target.NIF=:p_NIF";
                                        IQuery query = session.CreateQuery (sql).SetParameter ("p_NIF", NIF);



                                        result = query.List<EN.Petstore3.PedidoEN>();
                                }
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in ClienteCAD.", ex);
                }

                return result;
        }

        public System.Collections.Generic.IList<EN.Petstore3.PedidoEN>         DameCarrito (String NIF)
        {
                System.Collections.Generic.IList<EN.Petstore3.PedidoEN> result = null;
                try
                {
                        using (ISession session = NHibernateHelper.OpenSession ())
                                using (ITransaction tx = session.BeginTransaction ())
                                {
                                        String sql = @"select self FROM PedidoEN self inner join self.Cliente as target with target.NIF=:p_NIF";
                                        IQuery query = session.CreateQuery (sql).SetParameter ("p_NIF", NIF);



                                        result = query.List<EN.Petstore3.PedidoEN>();
                                }
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in ClienteCAD.", ex);
                }

                return result;
        }
        }
}
