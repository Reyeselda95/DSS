
using System;
using master8GenNHibernate.EN.Petstore3;

namespace master8GenNHibernate.CAD.Petstore3
{
        public interface ILineaPedidoCAD
        {
        LineaPedidoEN ReadOIDDefault (int numLinea);

        int New_ (LineaPedidoEN lineaPedido);

        void Destroy (int numLinea);


        void RelationerLinea (int p_LineaPedido_OID, int p_pedido_OID);

        EN.Petstore3.ArticuloEN         GetArticulo (int numLinea);
        }
}
