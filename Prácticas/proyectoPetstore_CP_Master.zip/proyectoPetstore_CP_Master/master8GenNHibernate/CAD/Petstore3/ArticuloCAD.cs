
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using master8GenNHibernate.EN.Petstore3;

namespace master8GenNHibernate.CAD.Petstore3
{
        public class ArticuloCAD : BasicCAD, IArticuloCAD
        {
        public ArticuloCAD() : base ()
        {
        }

        public ArticuloCAD(ISession sessionAux) : base (sessionAux)
        {
        }



        public ArticuloEN ReadOIDDefault (int numero)
        {
                ArticuloEN articuloEN = null;

                try
                {
                        SesssionInitializeTransaction ();
                        articuloEN = (ArticuloEN)session.Load (typeof(ArticuloEN),
                                numero

                                );
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in ArticuloCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }

                return articuloEN;
        }


        public int NuevoArticulo (ArticuloEN articulo)
        {
                try
                {
                        SesssionInitializeTransaction ();
                        if (articulo.Categoria != null) {
                                articulo.Categoria = (master8GenNHibernate.EN.Petstore3.CategoriaEN)session.Load (typeof(master8GenNHibernate.EN.Petstore3.CategoriaEN), articulo.Categoria.Id);
                        }

                        session.Save (articulo);
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in ArticuloCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }

                return articulo.Numero;
        }

        public void BorrarArticulo (int numero)
        {
                try
                {
                        SesssionInitializeTransaction ();
                        ArticuloEN articuloEN = (ArticuloEN)session.Load (typeof(ArticuloEN),
                                numero

                                );
                        session.Delete (articuloEN);
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in ArticuloCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }
        }

        public void Modificar (ArticuloEN articulo)
        {
                try
                {
                        SesssionInitializeTransaction ();
                        ArticuloEN articuloEN = (ArticuloEN)session.Load (typeof(ArticuloEN), articulo.Numero);

                        articuloEN.Nombre = articulo.Nombre;


                        articuloEN.Foto = articulo.Foto;


                        articuloEN.Precio = articulo.Precio;


                        articuloEN.Cantidad = articulo.Cantidad;


                        articuloEN.FotoGrande = articulo.FotoGrande;

                        session.Update (articuloEN);
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in ArticuloCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }
        }
        public void AnyadirAPedido (int p_Articulo_OID, System.Collections.Generic.IList<int> p_lineaPedido_OIDs)
        {
                master8GenNHibernate.EN.Petstore3.ArticuloEN articuloEN = null;
                try
                {
                        SesssionInitializeTransaction ();
                        articuloEN = (ArticuloEN)session.Load (typeof(ArticuloEN), p_Articulo_OID);
                        EN.Petstore3.LineaPedidoEN lineaPedidoEN = null;
                        if (articuloEN.LineaPedido == null) {
                                articuloEN.LineaPedido = new System.Collections.Generic.List<EN.Petstore3.LineaPedidoEN>();
                        }

                        foreach (int item in p_lineaPedido_OIDs) {
                                lineaPedidoEN = new EN.Petstore3.LineaPedidoEN ();
                                lineaPedidoEN = (EN.Petstore3.LineaPedidoEN)session.Load (typeof(EN.Petstore3.LineaPedidoEN), item);
                                articuloEN.LineaPedido.Add (lineaPedidoEN);
                        }


                        session.Update (articuloEN);
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in ArticuloCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }
        }

        public void QuitarDePedido (int p_Articulo_OID, System.Collections.Generic.IList<int> p_lineaPedido_OIDs)
        {
                try
                {
                        SesssionInitializeTransaction ();
                        master8GenNHibernate.EN.Petstore3.ArticuloEN articuloEN = null;
                        articuloEN = (ArticuloEN)session.Load (typeof(ArticuloEN), p_Articulo_OID);

                        EN.Petstore3.LineaPedidoEN lineaPedidoEN = null;
                        if (articuloEN.LineaPedido != null) {
                                foreach (int item in p_lineaPedido_OIDs) {
                                        lineaPedidoEN = new EN.Petstore3.LineaPedidoEN ();
                                        lineaPedidoEN.NumLinea = item;

                                        articuloEN.LineaPedido.Remove (lineaPedidoEN);
                                }
                        }

                        session.Update (articuloEN);
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in ArticuloCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }
        }
        public ArticuloEN DamePorOID (int numero)
        {
                ArticuloEN articuloEN = null;

                try
                {
                        SesssionInitializeTransaction ();
                        articuloEN = (ArticuloEN)session.Load (typeof(ArticuloEN),
                                numero

                                );
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in ArticuloCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }

                return articuloEN;
        }

        public System.Collections.Generic.IList<ArticuloEN> DameTodos (int first, int size)
        {
                System.Collections.Generic.IList<ArticuloEN> result = null;
                try
                {
                        SesssionInitializeTransaction ();
                        if (size > 0)
                                result = session.CreateCriteria (typeof(ArticuloEN)).
                                         SetFirstResult (first).SetMaxResults (size).List<ArticuloEN>();
                        else
                                result = session.CreateCriteria (typeof(ArticuloEN)).List<ArticuloEN>();
                        SessionCommit ();
                }

                catch (Exception ex) {
                        SessionRollBack ();
                        throw new DataLayerException ("Error in ArticuloCAD.", ex);
                }


                finally
                {
                        SessionClose ();
                }

                return result;
        }
        }
}
