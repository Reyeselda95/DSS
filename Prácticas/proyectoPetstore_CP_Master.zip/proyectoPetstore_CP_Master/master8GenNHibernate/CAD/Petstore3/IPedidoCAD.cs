
using System;
using master8GenNHibernate.EN.Petstore3;

namespace master8GenNHibernate.CAD.Petstore3
{
        public interface IPedidoCAD
        {
        PedidoEN ReadOIDDefault (int id);

        int CrearPedido (PedidoEN pedido);

        void ModificarPedido (PedidoEN pedido);


        void BorrarPedido (int id);


        PedidoEN ReadOID (int id);



        System.Collections.Generic.IList<EN.Petstore3.LineaPedidoEN>    GetAllLineaPedidos (int id);

        System.Collections.Generic.IList<EN.Petstore3.LineaPedidoEN>    DameLineas (int id);
        }
}
