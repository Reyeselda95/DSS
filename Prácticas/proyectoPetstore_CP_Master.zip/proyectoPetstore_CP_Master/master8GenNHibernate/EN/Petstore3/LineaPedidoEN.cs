
using System;

namespace master8GenNHibernate.EN.Petstore3
{
        public class LineaPedidoEN
        {
        /**
         *
         */

        private int numLinea;

        /**
         *
         */

        private Petstore3.PedidoEN pedido;

        /**
         *
         */

        private Petstore3.ArticuloEN articulo;

        /**
         *
         */

        private int cantidad;

        /**
         *
         */

        private double subtotal;

        /**
         *
         */

        private String observacion;





        public virtual int NumLinea { get { return numLinea; } set { numLinea = value;  } }


        public virtual Petstore3.PedidoEN Pedido { get { return pedido; } set { pedido = value;  } }


        public virtual Petstore3.ArticuloEN Articulo { get { return articulo; } set { articulo = value;  } }


        public virtual int Cantidad { get { return cantidad; } set { cantidad = value;  } }


        public virtual double Subtotal { get { return subtotal; } set { subtotal = value;  } }


        public virtual String Observacion { get { return observacion; } set { observacion = value;  } }



        public LineaPedidoEN()
        {
        }



        public LineaPedidoEN(int numLinea, Petstore3.PedidoEN pedido, Petstore3.ArticuloEN articulo, int cantidad, double subtotal, String observacion)
        {
                this.init (numLinea, pedido, articulo, cantidad, subtotal, observacion);
        }


        public LineaPedidoEN(LineaPedidoEN lineaPedido)
        {
                this.init (lineaPedido.NumLinea, lineaPedido.Pedido, lineaPedido.Articulo, lineaPedido.Cantidad, lineaPedido.Subtotal, lineaPedido.Observacion);
        }

        private void init (int numLinea, Petstore3.PedidoEN pedido, Petstore3.ArticuloEN articulo, int cantidad, double subtotal, String observacion)
        {
                this.NumLinea = numLinea;


                this.Pedido = pedido;

                this.Articulo = articulo;

                this.Cantidad = cantidad;

                this.Subtotal = subtotal;

                this.Observacion = observacion;
        }

        public override bool Equals (object obj)
        {
                if (obj == null)
                        return false;
                LineaPedidoEN t = obj as LineaPedidoEN;
                if (t == null)
                        return false;
                if (NumLinea.Equals (t.NumLinea))
                        return true;
                else
                        return false;
        }

        public override int GetHashCode ()
        {
                int hash = 13;

                hash += (null == NumLinea ? 0 : this.NumLinea.GetHashCode ());
                return hash;
        }
        }
}
