
using System;

namespace master8GenNHibernate.EN.Petstore3
{
        public class CategoriaEN
        {
        /**
         *
         */

        private int id;

        /**
         *
         */

        private String nombre;

        /**
         *
         */

        private String descripcion;

        /**
         *
         */

        private Petstore3.CategoriaEN categoria;

        /**
         *
         */

        private System.Collections.Generic.IList<Petstore3.CategoriaEN> subCategoria;

        /**
         *
         */

        private System.Collections.Generic.IList<Petstore3.ArticuloEN> articulo;

        /**
         *
         */

        private String foto;





        public virtual int Id { get { return id; } set { id = value;  } }


        public virtual String Nombre { get { return nombre; } set { nombre = value;  } }


        public virtual String Descripcion { get { return descripcion; } set { descripcion = value;  } }


        public virtual Petstore3.CategoriaEN Categoria { get { return categoria; } set { categoria = value;  } }


        public virtual System.Collections.Generic.IList<Petstore3.CategoriaEN> SubCategoria { get { return subCategoria; } set { subCategoria = value;  } }


        public virtual System.Collections.Generic.IList<Petstore3.ArticuloEN> Articulo { get { return articulo; } set { articulo = value;  } }


        public virtual String Foto { get { return foto; } set { foto = value;  } }



        public CategoriaEN()
        {
        }



        public CategoriaEN(int id, String nombre, String descripcion, Petstore3.CategoriaEN categoria, System.Collections.Generic.IList<Petstore3.CategoriaEN> subCategoria, System.Collections.Generic.IList<Petstore3.ArticuloEN> articulo, String foto)
        {
                this.init (id, nombre, descripcion, categoria, subCategoria, articulo, foto);
        }


        public CategoriaEN(CategoriaEN categoria)
        {
                this.init (categoria.Id, categoria.Nombre, categoria.Descripcion, categoria.Categoria, categoria.SubCategoria, categoria.Articulo, categoria.Foto);
        }

        private void init (int id, String nombre, String descripcion, Petstore3.CategoriaEN categoria, System.Collections.Generic.IList<Petstore3.CategoriaEN> subCategoria, System.Collections.Generic.IList<Petstore3.ArticuloEN> articulo, String foto)
        {
                this.Id = id;


                this.Nombre = nombre;

                this.Descripcion = descripcion;

                this.Categoria = categoria;

                this.SubCategoria = subCategoria;

                this.Articulo = articulo;

                this.Foto = foto;
        }

        public override bool Equals (object obj)
        {
                if (obj == null)
                        return false;
                CategoriaEN t = obj as CategoriaEN;
                if (t == null)
                        return false;
                if (Id.Equals (t.Id))
                        return true;
                else
                        return false;
        }

        public override int GetHashCode ()
        {
                int hash = 13;

                hash += (null == Id ? 0 : this.Id.GetHashCode ());
                return hash;
        }
        }
}
