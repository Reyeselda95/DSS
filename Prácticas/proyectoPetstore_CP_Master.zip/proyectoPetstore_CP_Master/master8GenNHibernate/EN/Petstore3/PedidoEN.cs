
using System;

namespace master8GenNHibernate.EN.Petstore3
{
        public class PedidoEN
        {
        /**
         *
         */

        private int id;

        /**
         *
         */

        private String descripcion;

        /**
         *
         */

        private Nullable<DateTime> fechaRealizacion;

        /**
         *
         */

        private System.Collections.Generic.IList<Petstore3.LineaPedidoEN> lineaPedido;

        /**
         *
         */

        private Petstore3.ClienteEN cliente;

        /**
         *
         */

        private Nullable<DateTime> fechaEnvio;

        /**
         *
         */

        private String estado;





        public virtual int Id { get { return id; } set { id = value;  } }


        public virtual String Descripcion { get { return descripcion; } set { descripcion = value;  } }


        public virtual Nullable<DateTime> FechaRealizacion { get { return fechaRealizacion; } set { fechaRealizacion = value;  } }


        public virtual System.Collections.Generic.IList<Petstore3.LineaPedidoEN> LineaPedido { get { return lineaPedido; } set { lineaPedido = value;  } }


        public virtual Petstore3.ClienteEN Cliente { get { return cliente; } set { cliente = value;  } }


        public virtual Nullable<DateTime> FechaEnvio { get { return fechaEnvio; } set { fechaEnvio = value;  } }


        public virtual String Estado { get { return estado; } set { estado = value;  } }



        public PedidoEN()
        {
        }



        public PedidoEN(int id, String descripcion, Nullable<DateTime> fechaRealizacion, System.Collections.Generic.IList<Petstore3.LineaPedidoEN> lineaPedido, Petstore3.ClienteEN cliente, Nullable<DateTime> fechaEnvio, String estado)
        {
                this.init (id, descripcion, fechaRealizacion, lineaPedido, cliente, fechaEnvio, estado);
        }


        public PedidoEN(PedidoEN pedido)
        {
                this.init (pedido.Id, pedido.Descripcion, pedido.FechaRealizacion, pedido.LineaPedido, pedido.Cliente, pedido.FechaEnvio, pedido.Estado);
        }

        private void init (int id, String descripcion, Nullable<DateTime> fechaRealizacion, System.Collections.Generic.IList<Petstore3.LineaPedidoEN> lineaPedido, Petstore3.ClienteEN cliente, Nullable<DateTime> fechaEnvio, String estado)
        {
                this.Id = id;


                this.Descripcion = descripcion;

                this.FechaRealizacion = fechaRealizacion;

                this.LineaPedido = lineaPedido;

                this.Cliente = cliente;

                this.FechaEnvio = fechaEnvio;

                this.Estado = estado;
        }

        public override bool Equals (object obj)
        {
                if (obj == null)
                        return false;
                PedidoEN t = obj as PedidoEN;
                if (t == null)
                        return false;
                if (Id.Equals (t.Id))
                        return true;
                else
                        return false;
        }

        public override int GetHashCode ()
        {
                int hash = 13;

                hash += (null == Id ? 0 : this.Id.GetHashCode ());
                return hash;
        }
        }
}
