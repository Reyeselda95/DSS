
using System;

namespace master8GenNHibernate.EN.Petstore3
{
        public class ArticuloEN
        {
        /**
         *
         */

        private int numero;

        /**
         *
         */

        private String nombre;

        /**
         *
         */

        private String foto;

        /**
         *
         */

        private double precio;

        /**
         *
         */

        private int cantidad;

        /**
         *
         */

        private Petstore3.CategoriaEN categoria;

        /**
         *
         */

        private System.Collections.Generic.IList<Petstore3.LineaPedidoEN> lineaPedido;

        /**
         *
         */

        private String fotoGrande;





        public virtual int Numero { get { return numero; } set { numero = value;  } }


        public virtual String Nombre { get { return nombre; } set { nombre = value;  } }


        public virtual String Foto { get { return foto; } set { foto = value;  } }


        public virtual double Precio { get { return precio; } set { precio = value;  } }


        public virtual int Cantidad { get { return cantidad; } set { cantidad = value;  } }


        public virtual Petstore3.CategoriaEN Categoria { get { return categoria; } set { categoria = value;  } }


        public virtual System.Collections.Generic.IList<Petstore3.LineaPedidoEN> LineaPedido { get { return lineaPedido; } set { lineaPedido = value;  } }


        public virtual String FotoGrande { get { return fotoGrande; } set { fotoGrande = value;  } }



        public ArticuloEN()
        {
        }



        public ArticuloEN(int numero, String nombre, String foto, double precio, int cantidad, Petstore3.CategoriaEN categoria, System.Collections.Generic.IList<Petstore3.LineaPedidoEN> lineaPedido, String fotoGrande)
        {
                this.init (numero, nombre, foto, precio, cantidad, categoria, lineaPedido, fotoGrande);
        }


        public ArticuloEN(ArticuloEN articulo)
        {
                this.init (articulo.Numero, articulo.Nombre, articulo.Foto, articulo.Precio, articulo.Cantidad, articulo.Categoria, articulo.LineaPedido, articulo.FotoGrande);
        }

        private void init (int numero, String nombre, String foto, double precio, int cantidad, Petstore3.CategoriaEN categoria, System.Collections.Generic.IList<Petstore3.LineaPedidoEN> lineaPedido, String fotoGrande)
        {
                this.Numero = numero;


                this.Nombre = nombre;

                this.Foto = foto;

                this.Precio = precio;

                this.Cantidad = cantidad;

                this.Categoria = categoria;

                this.LineaPedido = lineaPedido;

                this.FotoGrande = fotoGrande;
        }

        public override bool Equals (object obj)
        {
                if (obj == null)
                        return false;
                ArticuloEN t = obj as ArticuloEN;
                if (t == null)
                        return false;
                if (Numero.Equals (t.Numero))
                        return true;
                else
                        return false;
        }

        public override int GetHashCode ()
        {
                int hash = 13;

                hash += (null == Numero ? 0 : this.Numero.GetHashCode ());
                return hash;
        }
        }
}
