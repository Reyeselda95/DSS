
using System;

namespace master8GenNHibernate.EN.Petstore3
{
        public class ClienteEN
        {
        /**
         *
         */

        private String nIF;

        /**
         *
         */

        private String nombre;

        /**
         *
         */

        private String apellidos;

        /**
         *
         */

        private String direccion;

        /**
         *
         */

        private String telefono;

        /**
         *
         */

        private String cp;

        /**
         *
         */

        private System.Collections.Generic.IList<Petstore3.PedidoEN> pedido;

        /**
         *
         */

        private String password;





        public virtual String NIF { get { return nIF; } set { nIF = value;  } }


        public virtual String Nombre { get { return nombre; } set { nombre = value;  } }


        public virtual String Apellidos { get { return apellidos; } set { apellidos = value;  } }


        public virtual String Direccion { get { return direccion; } set { direccion = value;  } }


        public virtual String Telefono { get { return telefono; } set { telefono = value;  } }


        public virtual String Cp { get { return cp; } set { cp = value;  } }


        public virtual System.Collections.Generic.IList<Petstore3.PedidoEN> Pedido { get { return pedido; } set { pedido = value;  } }


        public virtual String Password { get { return password; } set { password = value;  } }



        public ClienteEN()
        {
        }



        public ClienteEN(String nIF, String nombre, String apellidos, String direccion, String telefono, String cp, System.Collections.Generic.IList<Petstore3.PedidoEN> pedido, String password)
        {
                this.init (nIF, nombre, apellidos, direccion, telefono, cp, pedido, password);
        }


        public ClienteEN(ClienteEN cliente)
        {
                this.init (cliente.NIF, cliente.Nombre, cliente.Apellidos, cliente.Direccion, cliente.Telefono, cliente.Cp, cliente.Pedido, cliente.Password);
        }

        private void init (String nIF, String nombre, String apellidos, String direccion, String telefono, String cp, System.Collections.Generic.IList<Petstore3.PedidoEN> pedido, String password)
        {
                this.NIF = NIF;


                this.Nombre = nombre;

                this.Apellidos = apellidos;

                this.Direccion = direccion;

                this.Telefono = telefono;

                this.Cp = cp;

                this.Pedido = pedido;

                this.Password = password;
        }

        public override bool Equals (object obj)
        {
                if (obj == null)
                        return false;
                ClienteEN t = obj as ClienteEN;
                if (t == null)
                        return false;
                if (NIF.Equals (t.NIF))
                        return true;
                else
                        return false;
        }

        public override int GetHashCode ()
        {
                int hash = 13;

                hash += (null == NIF ? 0 : this.NIF.GetHashCode ());
                return hash;
        }
        }
}
