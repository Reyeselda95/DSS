
using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using master8GenNHibernate.CAD.Petstore3;
using master8GenNHibernate.EN.Petstore3;
using master8GenNHibernate.CEN.Petstore3;
using master8GENCP.Petstore3;

namespace initializeDB
{
public class CreateDB
{
public static void Create (string databaseArg, string userArg, string passArg)
{
        String database = databaseArg;
        String user = userArg;
        String pass = passArg;

        // Conex DB
        SqlConnection cnn = new SqlConnection (@"Server=(local)\SQLEXPRESS; database=master; integrated security=yes");

        // Order T-SQL create user
        String createUser = @"IF NOT EXISTS(SELECT name FROM master.dbo.syslogins WHERE name = '" + user + @"')
            BEGIN
                CREATE LOGIN ["                                                                                                                                     + user + @"] WITH PASSWORD=N'" + pass + @"', DEFAULT_DATABASE=[master], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
            END"                                                                                                                                                                                                                                                                                    ;

        //Order delete user if exist
        String deleteDataBase = @"if exists(select * from sys.databases where name = '" + database + "') DROP DATABASE [" + database + "]";
        //Order create databas
        string createBD = "CREATE DATABASE " + database;
        //Order associate user with database
        String associatedUser = @"USE [" + database + "];CREATE USER [" + user + "] FOR LOGIN [" + user + "];USE [" + database + "];EXEC sp_addrolemember N'db_owner', N'" + user + "'";
        SqlCommand cmd = null;

        try
        {
                // Open conex
                cnn.Open ();

                //Create user in SQLSERVER
                cmd = new SqlCommand (createUser, cnn);
                cmd.ExecuteNonQuery ();

                //DELETE database if exist
                cmd = new SqlCommand (deleteDataBase, cnn);
                cmd.ExecuteNonQuery ();

                //CREATE DB
                cmd = new SqlCommand (createBD, cnn);
                cmd.ExecuteNonQuery ();

                //Associate user with db
                cmd = new SqlCommand (associatedUser, cnn);
                cmd.ExecuteNonQuery ();

                System.Console.WriteLine ("DataBase create sucessfully..");
        }
        catch (Exception ex)
        {
                throw ex;
        }
        finally
        {
                if (cnn.State == ConnectionState.Open) {
                        cnn.Close ();
                }
        }
}

public static void InitializeData ()
{
        /*PROTECTED REGION ID(initializeDataMethod) ENABLED START*/
        try
        {
            PedidoCP pedidoCP = new PedidoCP();
                ICategoriaCAD _ICategoriCAD = new CategoriaCAD ();
                IClienteCAD _IClienteCAD = new ClienteCAD ();
                IArticuloCAD _IArticuloCAD = new ArticuloCAD ();
                IPedidoCAD _IPedidoCAD = new PedidoCAD ();
                ClienteEN cliente1EN, cliente3EN = new ClienteEN ();
                ClienteCEN clienteCEN = new ClienteCEN (_IClienteCAD);
                CategoriaEN categoriaEN = new CategoriaEN ();
                CategoriaCEN categoriaCEN = new CategoriaCEN (_ICategoriCAD);
                PedidoEN pedidoEN = new PedidoEN ();
                PedidoCEN pedidoCEN = new PedidoCEN (_IPedidoCAD);
                ArticuloEN articulo1EN, articulo2EN, articulo3EN = new ArticuloEN ();
                ArticuloCEN articuloCEN = new ArticuloCEN (_IArticuloCAD);
                LineaPedidoEN lineaPedidoEN = new LineaPedidoEN ();
                System.Collections.Generic.List<LineaPedidoEN> lineas1, lineas2 = new List<LineaPedidoEN>();
                System.Collections.Generic.List<LineaPedidoEN> lineas3 = new List<LineaPedidoEN>();

                #region Cliente
                //Cliente 1
                cliente1EN = new ClienteEN ();
                cliente1EN.NIF = "11111111G";
                cliente1EN.Nombre = "Cliente1Nombre";
                cliente1EN.Apellidos = "Cliente1Apellidos";
                cliente1EN.Direccion = "Cliente1Direccion";
                cliente1EN.Telefono = "Cliente1Telefono";
                cliente1EN.Cp = "01234";
                cliente1EN.Password = "1";
                clienteCEN.CrearCliente (cliente1EN.NIF, cliente1EN.Nombre, cliente1EN.Apellidos, cliente1EN.Direccion, cliente1EN.Telefono, cliente1EN.Cp, cliente1EN.Password);
                #endregion

                #region Familia
                //Familia1
                categoriaEN.Nombre = "Familia1";
                categoriaEN.Descripcion = "Familia1Descripcion";
                categoriaEN.Foto = "";
                int idFamilia1 = categoriaEN.Id = categoriaCEN.Nueva (categoriaEN.Nombre, categoriaEN.Descripcion, categoriaEN.Foto);
                #endregion

                #region Articulo
                //Articulo 1
                articulo1EN = new ArticuloEN ();
                articulo1EN.Numero = 1;
                articulo1EN.Nombre = "Articulo 1";
                articulo1EN.Precio = 12.12;
                articulo1EN.Cantidad = 100;
                articulo1EN.Foto = @"http://1.bp.blogspot.com/_eSsjYrH82KM/SwVEyzsS6SI/AAAAAAAAAl8/qT7uSSyZP_c/s1600/carne.jpg";
                articulo1EN.FotoGrande = @"http://saboruniversal.com/wp-content/uploads/2008/03/carne_400x337.jpg";
                articulo1EN.Categoria = new CategoriaEN ();
                articulo1EN.Categoria.Id = idFamilia1;
                articuloCEN.NuevoArticulo (articulo1EN.Numero, articulo1EN.Nombre, articulo1EN.Foto,
                        articulo1EN.Precio, articulo1EN.Cantidad, articulo1EN.Categoria.Id, articulo1EN.FotoGrande);

                //Articulo 2
                articulo2EN = new ArticuloEN ();
                articulo2EN.Numero = 2;
                articulo2EN.Nombre = "Articulo 2";
                articulo2EN.Foto = @"http://img1cdn.adoosimg.com/ff957f43224750a44f7a2fdb3199-1-3.jpg";
                articulo2EN.Precio = 13.12;
                articulo2EN.Cantidad = 100;
                articulo2EN.FotoGrande = @"http://img1cdn.adoosimg.com/ff957f43224750a44f7a2fdb3199-1-3.jpg";
                articulo2EN.Categoria = new CategoriaEN ();
                articulo2EN.Categoria.Id = idFamilia1;
                articuloCEN.NuevoArticulo (articulo2EN.Numero, articulo2EN.Nombre, articulo2EN.Foto,
                        articulo2EN.Precio, articulo2EN.Cantidad, articulo2EN.Categoria.Id, articulo2EN.FotoGrande);

                //Articulo 3
                articulo3EN = new ArticuloEN ();
                articulo3EN.Numero = 3;
                articulo3EN.Nombre = "Articulo 3";
                articulo3EN.Foto = @"http://viviendosanos.com/wp-content/uploads/2007/06/carne.jpg";
                articulo3EN.Precio = 14.12;
                articulo3EN.Cantidad = 100;
                articulo3EN.FotoGrande = @"http://www.cocinaresfacil.net/images/pan-de-carne.jpg";
                articulo3EN.Categoria = new CategoriaEN ();
                articulo3EN.Categoria.Id = idFamilia1;
                articuloCEN.NuevoArticulo (articulo3EN.Numero, articulo3EN.Nombre, articulo3EN.Foto,
                        articulo3EN.Precio, articulo3EN.Cantidad, articulo3EN.Categoria.Id, articulo3EN.FotoGrande);

                #endregion

                #region LineaPedido
                lineas1 = new List<LineaPedidoEN>();
                //Linea de Pedido 1
                lineaPedidoEN = new LineaPedidoEN ();
                lineaPedidoEN.NumLinea = 1;
                lineaPedidoEN.Cantidad = 1;
                lineaPedidoEN.Subtotal = articulo1EN.Precio * lineaPedidoEN.Cantidad;
                lineaPedidoEN.Articulo = articulo1EN;
                lineas1.Add (lineaPedidoEN);

                //Linea de Pedido 2
                lineaPedidoEN = new LineaPedidoEN ();
                lineaPedidoEN.NumLinea = 2;
                lineaPedidoEN.Cantidad = 1;
                lineaPedidoEN.Subtotal = articulo2EN.Precio * lineaPedidoEN.Cantidad;
                lineaPedidoEN.Articulo = articulo2EN;
                lineas1.Add (lineaPedidoEN);

                //Linea de Pedido 3
                lineaPedidoEN = new LineaPedidoEN ();
                lineaPedidoEN.NumLinea = 3;
                lineaPedidoEN.Cantidad = 1;
                lineaPedidoEN.Subtotal = articulo3EN.Precio * lineaPedidoEN.Cantidad;
                lineaPedidoEN.Articulo = articulo3EN;
                lineas2.Add (lineaPedidoEN);

                //Linea de Pedido 4
                lineaPedidoEN = new LineaPedidoEN();
                lineaPedidoEN.NumLinea = 4;
                lineaPedidoEN.Cantidad = 12;
                lineaPedidoEN.Subtotal = articulo3EN.Precio * lineaPedidoEN.Cantidad;
                lineaPedidoEN.Articulo = articulo3EN;
                lineas3.Add(lineaPedidoEN);


                #endregion

                #region Pedido
                //Pedido 1
                pedidoEN.Descripcion = "Pedido1Descripcion";
                pedidoEN.FechaRealizacion = new DateTime (2010, 7, 26);
                pedidoEN.Estado = "Espera";
                pedidoEN.LineaPedido = lineas1;
                pedidoEN.FechaEnvio = null;
                pedidoEN.Cliente = new ClienteEN ();
                pedidoEN.Cliente.NIF = cliente1EN.NIF;
                pedidoCEN.CrearPedido (pedidoEN.Descripcion, pedidoEN.FechaRealizacion, lineas1, pedidoEN.Cliente.NIF, pedidoEN.FechaEnvio,
                        pedidoEN.Estado);

                //Pedido 2
                pedidoEN = new PedidoEN ();
                pedidoEN.Descripcion = "Pedido2Descripcion";
                pedidoEN.FechaRealizacion = new DateTime (2010, 7, 22);
                pedidoEN.Estado = "Enviado";
                pedidoEN.FechaEnvio = DateTime.Now;
                pedidoEN.LineaPedido = lineas2;
                pedidoEN.Cliente = new ClienteEN ();
                pedidoEN.Cliente.NIF = cliente1EN.NIF;
                pedidoCEN.CrearPedido (pedidoEN.Descripcion, pedidoEN.FechaRealizacion, lineas2, pedidoEN.Cliente.NIF, pedidoEN.FechaEnvio,
                        pedidoEN.Estado);
                #endregion

            //    pedidoCP.RestarStockyEnviarPedido("esto es una prueba", pedidoEN.FechaRealizacion, lineas3, cliente1EN.NIF, DateTime.Now, "enviado");
                /*PROTECTED REGION END*/
        }
        catch (Exception ex)
        {
                throw ex;
        }
}
}
}
