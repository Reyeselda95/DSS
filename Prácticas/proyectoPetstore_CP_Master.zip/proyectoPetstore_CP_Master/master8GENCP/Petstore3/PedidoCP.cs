﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using master8GenNHibernate.CAD.Petstore3;
using master8GenNHibernate.CEN.Petstore3;
using NHibernate;

namespace master8GENCP.Petstore3
{
    public class PedidoCP : BasicCP
    {

        public PedidoCP() : base() { }

        public PedidoCP(ISession sessionAux)
            : base(sessionAux)
        {
        }


        public int RestarStockyEnviarPedido(String p_descripcion, Nullable<DateTime> p_fechaRealizacion,
            System.Collections.Generic.IList<master8GenNHibernate.EN.Petstore3.LineaPedidoEN> p_lineaPedido,
            String p_cliente, Nullable<DateTime> p_fechaEnvio, String p_estado)
        {
            IPedidoCAD _IPedidoCAD = null;
            PedidoCEN pedidoCEN = null;
            ArticuloCP articuloCP = null;
            int oid = -1;

            try
            {
                SessionInitializeTransaction();
                //Llamada a CP de restar stock de los articulos
                articuloCP = new ArticuloCP(session); //Le pasamos la sesión así no volvemos a crear una nueva
                articuloCP.RestarStock(p_lineaPedido);
                _IPedidoCAD = new PedidoCAD(session);
                pedidoCEN = new PedidoCEN(_IPedidoCAD);
                //Creo el pedido
                sessionStarted = false; // Al llamar a otra operación dentro del mismo CP tenemos que poner la variable a false, y no inicie otra sesión.
                oid = CrearPedidoCP(p_descripcion, p_fechaRealizacion, p_lineaPedido, p_cliente,
                    p_fechaEnvio, p_estado);
                sessionStarted = true; // La ponemos a true para que haga commit.
                SessionCommit();

            }
            catch (Exception ex)
            {
                SessionRollBack();
                throw ex;
            }
            finally
            {
                SessionClose();
            }

            return oid;
        }
        public int CrearPedidoCP(String p_descripcion, Nullable<DateTime> p_fechaRealizacion,
            System.Collections.Generic.IList<master8GenNHibernate.EN.Petstore3.LineaPedidoEN> p_lineaPedido,
            String p_cliente, Nullable<DateTime> p_fechaEnvio, String p_estado)
        {
            IPedidoCAD _IPedidoCAD = null;
            PedidoCEN pedidoCEN = null;
            int oid = -1;

            try
            {
                SessionInitializeTransaction();
                _IPedidoCAD = new PedidoCAD(session);
                pedidoCEN = new PedidoCEN(_IPedidoCAD);
                oid=pedidoCEN.CrearPedido(p_descripcion, p_fechaRealizacion, p_lineaPedido, p_cliente,
                    p_fechaEnvio, p_estado);
                SessionCommit();

            }
            catch (Exception ex)
            {
                SessionRollBack();
                throw ex;
            }
            finally
            {
                SessionClose();
            }

            return oid;
        }
    }
}
