﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using master8GenNHibernate.EN.Petstore3;
using master8GenNHibernate.CAD.Petstore3;
using master8GenNHibernate.CEN.Petstore3;
using NHibernate;
using master8GenNHibernate.CEN;

namespace master8GENCP.Petstore3
{
    public class ArticuloCP : BasicCP
    {

        public ArticuloCP() : base() { }

        public ArticuloCP(ISession sessionAux)
            : base(sessionAux)
        {
        }
        public void RestarStock(System.Collections.Generic.IList<master8GenNHibernate.EN.Petstore3.LineaPedidoEN> p_lineaPedido)
        {
            IArticuloCAD _IArticuloCAD = null;
            ArticuloCEN articuloCEN = null;
            try
            {
                SessionInitializeTransaction();
                _IArticuloCAD = new ArticuloCAD(session);
                articuloCEN = new ArticuloCEN(_IArticuloCAD);
                ArticuloEN articuloEN = new ArticuloEN();
                int stock = 0;
                //recorro las lineas y resto el stock disponible
                foreach (LineaPedidoEN lineaPedidoEN in p_lineaPedido)
                {
                    stock = lineaPedidoEN.Articulo.Cantidad - lineaPedidoEN.Cantidad;
                    //Si el stock >=0 modifico el stock del articulo
                    if (stock >= 0)
                        articuloCEN.Modificar(lineaPedidoEN.Articulo.Numero,
                            lineaPedidoEN.Articulo.Nombre, lineaPedidoEN.Articulo.Foto,
                            lineaPedidoEN.Articulo.Precio, stock, lineaPedidoEN.Articulo.FotoGrande);

                        //Si es menor que cero lanzo una excepcion de stock insuficiente.
                    else
                        throw new ModelException("Stock insuficiente");
                }
                SessionCommit();
            }
            catch (Exception ex)
            {
                SessionRollBack();
                throw ex;
            }
            finally
            {
                SessionClose();
            }
        }
    }
}
