
using System;

namespace P1GenNHibernate.Enumerated.Práctica1
{
public enum EstadoPedidoEnum { pendiente=1, enviado=2, recibido=3, cancelado=4 };
}
