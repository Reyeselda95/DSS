
using System;
// Definición clase CategoryEN
namespace PruebaTextualGenNHibernate.EN.Default_
{
public partial class CategoryEN
{
/**
 *	Atributo product
 */
private System.Collections.Generic.IList<PruebaTextualGenNHibernate.EN.Default_.ProductEN> product;



/**
 *	Atributo categoryId
 */
private int categoryId;



/**
 *	Atributo name
 */
private string name;



/**
 *	Atributo descipcion
 */
private string descipcion;






public virtual System.Collections.Generic.IList<PruebaTextualGenNHibernate.EN.Default_.ProductEN> Product {
        get { return product; } set { product = value;  }
}



public virtual int CategoryId {
        get { return categoryId; } set { categoryId = value;  }
}



public virtual string Name {
        get { return name; } set { name = value;  }
}



public virtual string Descipcion {
        get { return descipcion; } set { descipcion = value;  }
}





public CategoryEN()
{
        product = new System.Collections.Generic.List<PruebaTextualGenNHibernate.EN.Default_.ProductEN>();
}



public CategoryEN(int categoryId, System.Collections.Generic.IList<PruebaTextualGenNHibernate.EN.Default_.ProductEN> product, string name, string descipcion
                  )
{
        this.init (CategoryId, product, name, descipcion);
}


public CategoryEN(CategoryEN category)
{
        this.init (CategoryId, category.Product, category.Name, category.Descipcion);
}

private void init (int categoryId, System.Collections.Generic.IList<PruebaTextualGenNHibernate.EN.Default_.ProductEN> product, string name, string descipcion)
{
        this.CategoryId = categoryId;


        this.Product = product;

        this.Name = name;

        this.Descipcion = descipcion;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        CategoryEN t = obj as CategoryEN;
        if (t == null)
                return false;
        if (CategoryId.Equals (t.CategoryId))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.CategoryId.GetHashCode ();
        return hash;
}
}
}
