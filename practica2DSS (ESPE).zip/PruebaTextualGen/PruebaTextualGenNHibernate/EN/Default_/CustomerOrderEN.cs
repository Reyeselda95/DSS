
using System;
// Definición clase CustomerOrderEN
namespace PruebaTextualGenNHibernate.EN.Default_
{
public partial class CustomerOrderEN
{
/**
 *	Atributo orderId
 */
private int orderId;



/**
 *	Atributo date
 */
private Nullable<DateTime> date;



/**
 *	Atributo address
 */
private string address;



/**
 *	Atributo city
 */
private string city;



/**
 *	Atributo state
 */
private string state;



/**
 *	Atributo zip
 */
private string zip;



/**
 *	Atributo paymentMethod
 */
private string paymentMethod;



/**
 *	Atributo status
 */
private PruebaTextualGenNHibernate.Enumerated.Default_.OrderStatusEnum status;



/**
 *	Atributo customer
 */
private PruebaTextualGenNHibernate.EN.Default_.CustomerEN customer;



/**
 *	Atributo orderLine
 */
private System.Collections.Generic.IList<PruebaTextualGenNHibernate.EN.Default_.OrderLineEN> orderLine;






public virtual int OrderId {
        get { return orderId; } set { orderId = value;  }
}



public virtual Nullable<DateTime> Date {
        get { return date; } set { date = value;  }
}



public virtual string Address {
        get { return address; } set { address = value;  }
}



public virtual string City {
        get { return city; } set { city = value;  }
}



public virtual string State {
        get { return state; } set { state = value;  }
}



public virtual string Zip {
        get { return zip; } set { zip = value;  }
}



public virtual string PaymentMethod {
        get { return paymentMethod; } set { paymentMethod = value;  }
}



public virtual PruebaTextualGenNHibernate.Enumerated.Default_.OrderStatusEnum Status {
        get { return status; } set { status = value;  }
}



public virtual PruebaTextualGenNHibernate.EN.Default_.CustomerEN Customer {
        get { return customer; } set { customer = value;  }
}



public virtual System.Collections.Generic.IList<PruebaTextualGenNHibernate.EN.Default_.OrderLineEN> OrderLine {
        get { return orderLine; } set { orderLine = value;  }
}





public CustomerOrderEN()
{
        orderLine = new System.Collections.Generic.List<PruebaTextualGenNHibernate.EN.Default_.OrderLineEN>();
}



public CustomerOrderEN(int orderId, Nullable<DateTime> date, string address, string city, string state, string zip, string paymentMethod, PruebaTextualGenNHibernate.Enumerated.Default_.OrderStatusEnum status, PruebaTextualGenNHibernate.EN.Default_.CustomerEN customer, System.Collections.Generic.IList<PruebaTextualGenNHibernate.EN.Default_.OrderLineEN> orderLine
                       )
{
        this.init (OrderId, date, address, city, state, zip, paymentMethod, status, customer, orderLine);
}


public CustomerOrderEN(CustomerOrderEN customerOrder)
{
        this.init (OrderId, customerOrder.Date, customerOrder.Address, customerOrder.City, customerOrder.State, customerOrder.Zip, customerOrder.PaymentMethod, customerOrder.Status, customerOrder.Customer, customerOrder.OrderLine);
}

private void init (int orderId, Nullable<DateTime> date, string address, string city, string state, string zip, string paymentMethod, PruebaTextualGenNHibernate.Enumerated.Default_.OrderStatusEnum status, PruebaTextualGenNHibernate.EN.Default_.CustomerEN customer, System.Collections.Generic.IList<PruebaTextualGenNHibernate.EN.Default_.OrderLineEN> orderLine)
{
        this.OrderId = orderId;


        this.Date = date;

        this.Address = address;

        this.City = city;

        this.State = state;

        this.Zip = zip;

        this.PaymentMethod = paymentMethod;

        this.Status = status;

        this.Customer = customer;

        this.OrderLine = orderLine;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        CustomerOrderEN t = obj as CustomerOrderEN;
        if (t == null)
                return false;
        if (OrderId.Equals (t.OrderId))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.OrderId.GetHashCode ();
        return hash;
}
}
}
