
using System;
// Definición clase OrderLineEN
namespace PruebaTextualGenNHibernate.EN.Default_
{
public partial class OrderLineEN
{
/**
 *	Atributo id
 */
private int id;



/**
 *	Atributo quantity
 */
private int quantity;



/**
 *	Atributo number
 */
private int number;



/**
 *	Atributo product
 */
private PruebaTextualGenNHibernate.EN.Default_.ProductEN product;



/**
 *	Atributo order
 */
private PruebaTextualGenNHibernate.EN.Default_.CustomerOrderEN order;






public virtual int Id {
        get { return id; } set { id = value;  }
}



public virtual int Quantity {
        get { return quantity; } set { quantity = value;  }
}



public virtual int Number {
        get { return number; } set { number = value;  }
}



public virtual PruebaTextualGenNHibernate.EN.Default_.ProductEN Product {
        get { return product; } set { product = value;  }
}



public virtual PruebaTextualGenNHibernate.EN.Default_.CustomerOrderEN Order {
        get { return order; } set { order = value;  }
}





public OrderLineEN()
{
}



public OrderLineEN(int id, int quantity, int number, PruebaTextualGenNHibernate.EN.Default_.ProductEN product, PruebaTextualGenNHibernate.EN.Default_.CustomerOrderEN order
                   )
{
        this.init (Id, quantity, number, product, order);
}


public OrderLineEN(OrderLineEN orderLine)
{
        this.init (Id, orderLine.Quantity, orderLine.Number, orderLine.Product, orderLine.Order);
}

private void init (int id, int quantity, int number, PruebaTextualGenNHibernate.EN.Default_.ProductEN product, PruebaTextualGenNHibernate.EN.Default_.CustomerOrderEN order)
{
        this.Id = id;


        this.Quantity = quantity;

        this.Number = number;

        this.Product = product;

        this.Order = order;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        OrderLineEN t = obj as OrderLineEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
