
using System;
using PruebaTextualGenNHibernate.EN.Default_;

namespace PruebaTextualGenNHibernate.CAD.Default_
{
public partial interface ICustomerOrderCAD
{
CustomerOrderEN ReadOIDDefault (int orderId);

void DeleteOrderLine (int p_customerorder, System.Collections.Generic.IList<int> p_orderline);

void AddOrderLine (int p_customerorder, System.Collections.Generic.IList<int> p_orderline);

CustomerOrderEN GetByOID (int orderId);


System.Collections.Generic.IList<CustomerOrderEN> GetAllOrders (int first, int size);


void DeleteOrder (int orderId);


void ModifyOrder (CustomerOrderEN customerOrder);


int CreateOrder (CustomerOrderEN customerOrder);
}
}
