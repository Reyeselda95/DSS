
using System;
using PruebaTextualGenNHibernate.EN.Default_;

namespace PruebaTextualGenNHibernate.CAD.Default_
{
public partial interface IProductCAD
{
ProductEN ReadOIDDefault (int productId);

System.Collections.Generic.IList<ProductEN> GetAllProducts (int first, int size);




void Modify (ProductEN product);


void Delete (int productId);


int Create (ProductEN product);
}
}
