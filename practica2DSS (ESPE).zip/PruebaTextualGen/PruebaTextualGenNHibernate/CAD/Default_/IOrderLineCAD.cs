
using System;
using PruebaTextualGenNHibernate.EN.Default_;

namespace PruebaTextualGenNHibernate.CAD.Default_
{
public partial interface IOrderLineCAD
{
OrderLineEN ReadOIDDefault (int id);

void ModifyLine (OrderLineEN orderLine);


int CreateOrderLine (OrderLineEN orderLine);
}
}
