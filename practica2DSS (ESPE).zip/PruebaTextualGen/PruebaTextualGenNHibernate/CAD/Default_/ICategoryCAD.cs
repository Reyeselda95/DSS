
using System;
using PruebaTextualGenNHibernate.EN.Default_;

namespace PruebaTextualGenNHibernate.CAD.Default_
{
public partial interface ICategoryCAD
{
CategoryEN ReadOIDDefault (int categoryId);

int New_ (CategoryEN category);

void Destroy (int categoryId);


void Modify (CategoryEN category);
}
}
