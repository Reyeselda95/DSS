
using System;
using PruebaTextualGenNHibernate.EN.Default_;

namespace PruebaTextualGenNHibernate.CAD.Default_
{
public partial interface ICustomerCAD
{
CustomerEN ReadOIDDefault (int idnumber);


void DeleteCustomer (int idnumber);


void ModififyCustomer (CustomerEN customer);


CustomerEN GetCustomerByOID (int idnumber);


int CreateCustomer (CustomerEN customer);
}
}
