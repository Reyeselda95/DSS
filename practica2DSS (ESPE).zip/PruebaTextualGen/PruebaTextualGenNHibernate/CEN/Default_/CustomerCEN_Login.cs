
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using PruebaTextualGenNHibernate.EN.Default_;
using PruebaTextualGenNHibernate.CAD.Default_;

namespace PruebaTextualGenNHibernate.CEN.Default_
{
public partial class CustomerCEN
{
public bool Login (int p_oid, string password)
{
        /*PROTECTED REGION ID(PruebaTextualGenNHibernate.CEN.Default__Customer_login) ENABLED START*/

        // Write here your custom code...
        bool result = false;
        CustomerEN customer = _ICustomerCAD.GetCustomerByOID (p_oid);

        if (customer.Password.Equals (password))
                result = true;
        return result;

        /*PROTECTED REGION END*/
}
}
}
