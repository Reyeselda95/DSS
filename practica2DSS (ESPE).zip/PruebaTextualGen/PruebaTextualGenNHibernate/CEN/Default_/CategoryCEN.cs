

using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using PruebaTextualGenNHibernate.EN.Default_;
using PruebaTextualGenNHibernate.CAD.Default_;

namespace PruebaTextualGenNHibernate.CEN.Default_
{
/*
 *      Definition of the class CategoryCEN
 *
 */
public partial class CategoryCEN
{
private ICategoryCAD _ICategoryCAD;

public CategoryCEN()
{
        this._ICategoryCAD = new CategoryCAD ();
}

public CategoryCEN(ICategoryCAD _ICategoryCAD)
{
        this._ICategoryCAD = _ICategoryCAD;
}

public ICategoryCAD get_ICategoryCAD ()
{
        return this._ICategoryCAD;
}

public int New_ (string p_name)
{
        CategoryEN categoryEN = null;
        int oid;

        //Initialized CategoryEN
        categoryEN = new CategoryEN ();
        categoryEN.Name = p_name;

        //Call to CategoryCAD

        oid = _ICategoryCAD.New_ (categoryEN);
        return oid;
}

public void Destroy (int categoryId)
{
        _ICategoryCAD.Destroy (categoryId);
}

public void Modify (int p_oid, string p_name)
{
        CategoryEN categoryEN = null;

        //Initialized CategoryEN
        categoryEN = new CategoryEN ();
        categoryEN.CategoryId = p_oid;
        categoryEN.Name = p_name;
        //Call to CategoryCAD

        _ICategoryCAD.Modify (categoryEN);
}
}
}
