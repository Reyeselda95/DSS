
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using PruebaTextualGenNHibernate.EN.Default_;
using PruebaTextualGenNHibernate.CAD.Default_;

namespace PruebaTextualGenNHibernate.CEN.Default_
{
public partial class ProductCEN
{
public void DecreaseStock (int p_oid, int cant)
{
        /*PROTECTED REGION ID(PruebaTextualGenNHibernate.CEN.Default__Product_decreaseStock) ENABLED START*/

        // Write here your custom code...

        ProductEN producto = _IProductCAD.ReadOIDDefault (p_oid);

        producto.Stock -= cant;
        _IProductCAD.Modify (producto);

        /*PROTECTED REGION END*/
}
}
}
