
using System;

namespace PruebaTextualGenNHibernate.Enumerated.Default_
{
public enum OrderStatusEnum { pending=1, sent=2, received=3, cancelled=4 };
}
